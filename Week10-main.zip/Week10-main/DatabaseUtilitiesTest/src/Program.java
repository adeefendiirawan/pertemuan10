
public class Program {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            KoneksiDatabase.getKoneksi();
    }
    
}
